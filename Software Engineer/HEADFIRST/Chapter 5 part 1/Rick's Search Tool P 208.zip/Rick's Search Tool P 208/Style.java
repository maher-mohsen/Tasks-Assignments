public enum Style{
    A,F;
}