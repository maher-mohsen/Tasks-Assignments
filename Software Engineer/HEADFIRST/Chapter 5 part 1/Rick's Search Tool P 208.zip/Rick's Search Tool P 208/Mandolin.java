public class Mandolin extends Instrument{
    public Mandolin(String serialNumber,double price,MandolinSpec spec){
        super(serialNumber,price,spec);
    }
    
}
